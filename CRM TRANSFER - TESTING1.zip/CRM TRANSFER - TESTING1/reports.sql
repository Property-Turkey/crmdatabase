-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 04, 2024 at 04:52 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.1.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `transfer_crm`
--

-- --------------------------------------------------------

--
-- Table structure for table `reports`
--

CREATE TABLE `reports` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `tar_id` int(11) NOT NULL COMMENT 'target id (record id)',
  `tar_tbl` varchar(255) NOT NULL COMMENT 'target table (leads, clients, book, etc)',
  `report_type` int(11) NOT NULL COMMENT 'category.id empathy, Ideal prospects, etc',
  `report_priority` tinyint(4) NOT NULL DEFAULT 5 COMMENT '1=top, 5=normal, 10=last',
  `report_text` text NOT NULL,
  `stat_created` datetime NOT NULL,
  `rec_state` tinyint(4) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reports`
--

INSERT INTO `reports` (`id`, `user_id`, `tar_id`, `tar_tbl`, `report_type`, `report_priority`, `report_text`, `stat_created`, `rec_state`) VALUES
(1, 149, 1, 'Clients', 60, 5, 'When are you planning to buy ?<br />Within next 3 months<br /><br />How can we help you ?<br />I would like to make an offer on this property<br /><br />Note : what is final offer\n and how much in USA dollar please<br />', '0000-00-00 00:00:00', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `reports`
--
ALTER TABLE `reports`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `reports`
--
ALTER TABLE `reports`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
