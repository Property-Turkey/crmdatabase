-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 04, 2024 at 04:52 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.1.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `transfer_crm`
--

-- --------------------------------------------------------

--
-- Table structure for table `enquires`
--

CREATE TABLE `enquires` (
  `id` int(11) NOT NULL,
  `client_id` int(11) DEFAULT NULL,
  `property_id` int(11) DEFAULT NULL,
  `enquiry_name` varchar(255) DEFAULT NULL,
  `enquiry_email` varchar(255) NOT NULL,
  `enquiry_phone` int(255) DEFAULT NULL,
  `enquiry_country` int(11) DEFAULT NULL,
  `enquiry_source` int(11) DEFAULT NULL,
  `enquiry_message` varchar(255) DEFAULT NULL,
  `enquiry_ipaddress` varchar(255) DEFAULT NULL,
  `enquiry_referral` varchar(255) DEFAULT NULL,
  `seo_keywords` varchar(255) DEFAULT NULL,
  `stat_host` varchar(255) DEFAULT NULL,
  `stat_isindex` tinyint(4) DEFAULT 0,
  `stat_created` datetime DEFAULT current_timestamp(),
  `stat_updated` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `enquires`
--

INSERT INTO `enquires` (`id`, `client_id`, `property_id`, `enquiry_name`, `enquiry_email`, `enquiry_phone`, `enquiry_country`, `enquiry_source`, `enquiry_message`, `enquiry_ipaddress`, `enquiry_referral`, `seo_keywords`, `stat_host`, `stat_isindex`, `stat_created`, `stat_updated`) VALUES
(1, 1, 99276, 'Houel Gilbert', 'mgbhpsh@gmail.com', NULL, NULL, NULL, 'What is the rental incom % ?Can I get rescidents visa for property investment ?', NULL, NULL, 'a:6:{i:0;s:8:\"istanbul\";i:1;s:5:\"prime\";i:2;s:8:\"location\";i:3;s:8:\"property\";i:4;s:3:\"for\";i:5;s:4:\"sale\";}', 'google', 0, NULL, NULL),
(2, 1, 99276, 'Houel Gilbert', 'mgbhpsh@gmail.com', NULL, NULL, NULL, 'What is the rental incom % ?Can I get rescidents visa for property investment ?', NULL, NULL, 'a:6:{i:0;s:8:\"istanbul\";i:1;s:5:\"prime\";i:2;s:8:\"location\";i:3;s:8:\"property\";i:4;s:3:\"for\";i:5;s:4:\"sale\";}', 'google', 0, NULL, NULL),
(3, 1, 99103, 'Houel Gilbert', 'mgbhpsh@gmail.com', NULL, NULL, NULL, 'Need to see layout plan and the view !!!', NULL, NULL, 'a:1:{i:0;s:0:\"\";}', NULL, 0, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `enquires`
--
ALTER TABLE `enquires`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `enquires`
--
ALTER TABLE `enquires`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
